package com.unity3d.player;

import android.app.Activity;

public class UnityPlayerActivity extends Activity {
    // used in order to intergate menu view to game
    public UnityPlayer mUnityPlayer;

}
