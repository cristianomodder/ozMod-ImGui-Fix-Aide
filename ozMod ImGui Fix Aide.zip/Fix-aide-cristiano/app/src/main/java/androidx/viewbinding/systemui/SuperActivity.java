package androidx.viewbinding.systemui;

import android.app.Activity;

public class SuperActivity extends Activity {

}
