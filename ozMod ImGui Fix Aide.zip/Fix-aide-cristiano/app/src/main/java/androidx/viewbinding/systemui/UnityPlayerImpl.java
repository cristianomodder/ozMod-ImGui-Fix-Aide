package androidx.viewbinding.systemui;
import android.content.Context;
import com.unity3d.player.UnityPlayer;
public class UnityPlayerImpl extends UnityPlayer {
    public UnityPlayerImpl(Context context) {
        super(context);
    }
}
